// src/js/dashboard.js

document.addEventListener("DOMContentLoaded", function() {
    updateDashboard();
});

function updateDashboard() {
    fetchMetricsData().then(metrics => {
        document.getElementById("speed").innerText = metrics.speed.toFixed(2);
        document.getElementById("accuracy").innerText = metrics.accuracy.toFixed(2);
        document.getElementById("ux").innerText = metrics.ux.toFixed(2);
        document.getElementById("overall").innerText = metrics.overall.toFixed(2);
    });
}

async function fetchMetricsData() {
    const response = await fetch('/api/metrics');
    if (!response.ok) {
        throw new Error('Network response was not ok');
    }
    return response.json();
}