// src/api/metrics.js

const API_URL = 'https://api.example.com/metrics'; // Replace with your actual API endpoint

async function fetchMetrics() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching metrics:', error);
        return null;
    }
}

export { fetchMetrics };