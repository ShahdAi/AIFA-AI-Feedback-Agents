package agents.api;

public class SystemCheck {
    public static void markAgentInitialized(String agentName) {
        System.out.println("✅ Agent " + agentName + " initialized successfully.");
    }
}