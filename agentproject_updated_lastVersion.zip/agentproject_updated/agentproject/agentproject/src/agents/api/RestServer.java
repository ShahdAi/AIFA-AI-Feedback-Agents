package agents.api;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import com.google.gson.Gson;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import agents.DecisionAgent;
import agents.ReportStore;

public class RestServer implements Runnable {
    private final DecisionAgent agent;
    private static final int PORT = 8090;
    private static final Gson gson = new Gson();

    public RestServer(DecisionAgent agent) {
        this.agent = agent;
    }

    public void start() {
        new Thread(this).start();
    }

    @Override
    public void run() {
        try {
            Server server = new Server(PORT);
            ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
            context.setContextPath("/");
            server.setHandler(context);

            context.addServlet(new ServletHolder(new FeedbackApiEndpoint()), "/api/feedback/*");
            
            server.start();
            System.out.println("REST Server started on port " + PORT);
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class FeedbackApiEndpoint extends HttpServlet {
        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
                throws IOException {
            resp.setContentType("application/json");
            resp.setStatus(HttpServletResponse.SC_OK);
            
            var feedback = new FeedbackResponse(
                ReportStore.getSpeed(),
                ReportStore.getAccuracy(),
                ReportStore.getUx(),
                ReportStore.getOverall()
            );
            
            resp.getWriter().write(gson.toJson(feedback));
        }
        
        private static class FeedbackResponse {
            public final double speed;
            public final double accuracy;
            public final double ux;
            public final double overall;
            
            public FeedbackResponse(double s, double a, double u, double o) {
                speed = s;
                accuracy = a;
                ux = u;
                overall = o;
            }
        }
    }
}