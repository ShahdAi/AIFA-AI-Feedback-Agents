package agents;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.List;

public class SpeedFeedbackAgent extends Agent {
    private List<Integer> speedRatings = new ArrayList<>();

    protected void setup() {
        System.out.println(getLocalName() + " is ready");

        addBehaviour(new CyclicBehaviour(this) {
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    String ontology = msg.getOntology();
                    String content = msg.getContent();
                    if ("speed".equals(ontology) && content != null) {
                        int rating = Integer.parseInt(content);
                        speedRatings.add(rating);
                        System.out.println("✅ Speed agent received rating: " + rating);
                    } else if ("report".equals(content)) {
                        double average = speedRatings.stream()
                            .mapToDouble(Integer::doubleValue)
                            .average()
                            .orElse(0.0);

                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.INFORM);
                        reply.setContent(String.format("%.2f", average));
                        send(reply);
                    }
                } else {
                    block();
                }
            }
        });
    }
}
