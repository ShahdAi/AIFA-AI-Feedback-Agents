package agents;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class DashboardUI extends JFrame {
    private static final DashboardUI instance = new DashboardUI();
    private final JLabel speedLabel;
    private final JLabel accuracyLabel;
    private final JLabel uxLabel;
    private final JLabel overallLabel;
    private final DecimalFormat df = new DecimalFormat("#0.00");

    private DashboardUI() {
        super("AI Feedback Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Main panel with GridBagLayout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(240, 240, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Title
        JLabel titleLabel = new JLabel("AI Feedback Summary");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(titleLabel, gbc);

        // Initialize metric labels
        speedLabel = createMetricPanel("Speed Rating", 1);
        accuracyLabel = createMetricPanel("Accuracy Rating", 2);
        uxLabel = createMetricPanel("UX Rating", 3);
        overallLabel = createMetricPanel("Overall Rating", 4);

        // Add metric panels to main panel
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridy = 1;
        mainPanel.add(createMetricContainer("Speed Rating:", speedLabel), gbc);
        gbc.gridy = 2;
        mainPanel.add(createMetricContainer("Accuracy Rating:", accuracyLabel), gbc);
        gbc.gridy = 3;
        mainPanel.add(createMetricContainer("UX Rating:", uxLabel), gbc);
        gbc.gridy = 4;
        mainPanel.add(createMetricContainer("Overall Rating:", overallLabel), gbc);

        add(mainPanel);
        
        // Initial update
        updateValues();
    }

    private JPanel createMetricContainer(String labelText, JLabel valueLabel) {
        JPanel panel = new JPanel(new BorderLayout(10, 0));
        panel.setOpaque(false);
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(label, BorderLayout.WEST);
        panel.add(valueLabel, BorderLayout.CENTER);
        return panel;
    }

    private JLabel createMetricPanel(String text, int row) {
        JLabel label = new JLabel("0.00");
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        return label;
    }

    public static void showDashboard() {
        SwingUtilities.invokeLater(() -> {
            instance.setVisible(true);
        });
    }

    public static void update() {
        SwingUtilities.invokeLater(() -> {
            instance.updateValues();
        });
    }

    private void updateValues() {
        speedLabel.setText(df.format(ReportStore.getSpeed()));
        accuracyLabel.setText(df.format(ReportStore.getAccuracy()));
        uxLabel.setText(df.format(ReportStore.getUx()));
        overallLabel.setText(df.format(ReportStore.getOverall()));
    }
}