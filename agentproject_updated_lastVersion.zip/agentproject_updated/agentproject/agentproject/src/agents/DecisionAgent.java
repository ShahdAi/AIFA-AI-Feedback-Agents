package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.HashMap;
import java.util.Map;
import java.io.IOException;

public class DecisionAgent extends Agent {
    private Map<String, Double> reports = new HashMap<>();

    protected void setup() {
        System.out.println(getLocalName() + " is ready");
        
        // Start dashboard server
        try {
            new DashboardServer().start();
        } catch (IOException e) {
            System.err.println("Could not start dashboard server: " + e.getMessage());
        }
        DashboardUI.showDashboard();

        addBehaviour(new CyclicBehaviour(this) {
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    // Trigger report collection when feedback is complete
                    if ("feedback-done".equals(msg.getOntology())
                        || "feedback-done".equals(msg.getContent())
                        || "done=true".equalsIgnoreCase(msg.getContent())) {
                        requestReports();
                    } else {
                        try {
                            double rating = Double.parseDouble(msg.getContent());
                            String agentName = msg.getSender().getLocalName();
                            reports.put(agentName, rating);

                            // Once all three reports are received, generate summary
                            if (reports.size() == 3) {
                                generateFinalReport();
                                reports.clear();
                            }
                        } catch (NumberFormatException e) {
                            // Ignore non-numeric messages
                        }
                    }
                } else {
                    block();
                }
            }
        });
    }

    private void requestReports() {
        ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);
        msg.setContent("report");
        msg.addReceiver(new AID("speed", AID.ISLOCALNAME));
        msg.addReceiver(new AID("accuracy", AID.ISLOCALNAME));
        msg.addReceiver(new AID("ux", AID.ISLOCALNAME));
        send(msg);
    }

    private void generateFinalReport() {
        double speedRating = reports.getOrDefault("speed", 0.0);
        double accuracyRating = reports.getOrDefault("accuracy", 0.0);
        double uxRating = reports.getOrDefault("ux", 0.0);

        // Store results in ReportStore for permanent storage
        ReportStore.set(speedRating, accuracyRating, uxRating);

        double overallAverage = (speedRating + accuracyRating + uxRating) / 3.0;

        // Output the summary report
        System.out.println("\n=== 🧠 AI Feedback Summary Report ===");
        System.out.printf("- From SPEED agent: Average Speed Rating: %.2f%n", speedRating);
        System.out.printf("- From ACCURACY agent: Average Accuracy Rating: %.2f%n", accuracyRating);
        System.out.printf("- From UX agent: Average UX Rating: %.2f%n", uxRating);
        System.out.printf("💡 Overall Average Rating: %.2f%n", overallAverage);
        System.out.println("✅ All reports collected successfully!");
        
        // Update the dashboard
        DashboardUI.update();
    }
}
