package agents;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.List;

public class UXFeedbackAgent extends Agent {
    private List<Integer> uxRatings = new ArrayList<>();

    protected void setup() {
        System.out.println(getLocalName() + " is ready");

        addBehaviour(new CyclicBehaviour(this) {
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    String ontology = msg.getOntology();
                    String content = msg.getContent();
                    if ("ux".equals(ontology) && content != null) {
                        int rating = Integer.parseInt(content);
                        uxRatings.add(rating);
                        System.out.println("✅ UX agent received rating: " + rating);
                    } else if ("report".equals(content)) {
                        double average = uxRatings.stream()
                            .mapToDouble(Integer::doubleValue)
                            .average()
                            .orElse(0.0);

                        ACLMessage reply = msg.createReply();
                        reply.setPerformative(ACLMessage.INFORM);
                        reply.setOntology("ux");
                        reply.setContent(String.format("%.2f", average));
                        send(reply);
                    }
                } else {
                    block();
                }
            }
        });
    }
}
