package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.lang.acl.ACLMessage;

import javax.swing.*;
import java.awt.*;

public class FeedbackSourceAgent extends Agent {
    private int feedbackCount = 0;

    @Override
    protected void setup() {
        System.out.println(getLocalName() + " started (Feedback GUI Active).");

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("AI Feedback Collector");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(380, 230);
            frame.setLocationRelativeTo(null);

            JTextField speedField = new JTextField();
            JTextField accuracyField = new JTextField();
            JTextField uxField = new JTextField();

            JLabel statusLabel = new JLabel("Waiting for input...");
            JLabel countLabel = new JLabel("Feedback count: 0");

            JButton addButton = new JButton("Add Feedback");
            JButton finishButton = new JButton("Finish & Generate Report");

            JPanel panel = new JPanel(new GridLayout(6, 2, 6, 6));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            panel.add(new JLabel("Speed Rating (1-5):")); panel.add(speedField);
            panel.add(new JLabel("Accuracy Rating (1-5):")); panel.add(accuracyField);
            panel.add(new JLabel("UX Rating (1-5):")); panel.add(uxField);
            panel.add(addButton); panel.add(finishButton);
            panel.add(statusLabel); panel.add(countLabel);

            frame.setContentPane(panel);
            frame.setVisible(true);

            addButton.addActionListener(e -> {
                try {
                    int speed = Integer.parseInt(speedField.getText().trim());
                    int acc = Integer.parseInt(accuracyField.getText().trim());
                    int ux = Integer.parseInt(uxField.getText().trim());

                    if (!isValid(speed) || !isValid(acc) || !isValid(ux)) {
                        statusLabel.setText("⚠️ Enter values between 1 and 5");
                        return;
                    }

                    sendRating("speed", speed);
                    sendRating("accuracy", acc);
                    sendRating("ux", ux);

                    feedbackCount++;
                    countLabel.setText("Feedback count: " + feedbackCount);
                    statusLabel.setText("✅ Feedback sent #" + feedbackCount);

                    speedField.setText("");
                    accuracyField.setText("");
                    uxField.setText("");
                } catch (Exception ex) {
                    statusLabel.setText("⚠️ Invalid input, please enter integers 1-5");
                }
            });

            finishButton.addActionListener(e -> {
                sendFeedbackDone();
                statusLabel.setText("📤 Finished – report requested.");
            });
        });
    }

    private boolean isValid(int x) {
        return x >= 1 && x <= 5;
    }

    private void sendRating(String agent, int value) {
        ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
        msg.addReceiver(new AID(agent, AID.ISLOCALNAME));
        msg.setOntology(agent);
        msg.setLanguage("English");
        msg.setContent(String.valueOf(value));
        send(msg);
        System.out.println("[GUI->" + agent + "] rating=" + value);
    }

    private void sendFeedbackDone() {
        ACLMessage done = new ACLMessage(ACLMessage.INFORM);
        done.addReceiver(new AID("decision", AID.ISLOCALNAME));
        done.setOntology("feedback-done");
        done.setContent("done=true");
        send(done);
        System.out.println("📤 Sent → feedback-done to DecisionAgent");
    }
}
