package agents;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.List;

public class AccuracyFeedbackAgent extends Agent {
    private List<Integer> accuracyRatings = new ArrayList<>();

    protected void setup() {
        System.out.println(getLocalName() + " is ready");

        addBehaviour(new CyclicBehaviour(this) {
            public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                String ontology = msg.getOntology();
                String content = msg.getContent();
                if ("accuracy".equals(ontology) && content != null) {
                    int rating = Integer.parseInt(content);
                    accuracyRatings.add(rating);
                    System.out.println("✅ Accuracy agent received rating: " + rating);
                } else if ("report".equals(content)) {
                    double average = accuracyRatings.stream()
                        .mapToDouble(Integer::doubleValue)
                        .average()
                        .orElse(0.0);
                    ACLMessage reply = msg.createReply();
                    reply.setPerformative(ACLMessage.INFORM);
                    reply.setOntology("accuracy");
                    reply.setContent(String.format("%.2f", average));
                    send(reply);
                }
            } else {
                block();
            }
            }
        });
    }
}
