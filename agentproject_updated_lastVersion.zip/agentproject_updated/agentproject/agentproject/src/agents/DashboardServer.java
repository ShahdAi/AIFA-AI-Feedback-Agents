package agents;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class DashboardServer {
    private static final int PORT = 8000;
    private HttpServer server;

    public void start() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        
        // Handle metrics API requests
        server.createContext("/metrics", new MetricsHandler());
        server.setExecutor(null);
        server.start();
        
        System.out.println("Dashboard server started on port " + PORT);
        System.out.println("Open dashboard.html in your browser to view metrics");
    }

    static class MetricsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String response = String.format(
                "{\"speed\": %.2f, \"accuracy\": %.2f, \"ux\": %.2f, \"overall\": %.2f}",
                ReportStore.getSpeed(),
                ReportStore.getAccuracy(),
                ReportStore.getUx(),
                ReportStore.getOverall()
            );
            
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.sendResponseHeaders(200, response.length());
            
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
        }
    }
}