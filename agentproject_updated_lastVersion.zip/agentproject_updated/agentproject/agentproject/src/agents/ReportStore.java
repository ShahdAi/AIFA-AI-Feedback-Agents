package agents;

import java.util.concurrent.atomic.AtomicReference;

public final class ReportStore {
    private static final AtomicReference<Double> speed = new AtomicReference<>(0.0);
    private static final AtomicReference<Double> accuracy = new AtomicReference<>(0.0);
    private static final AtomicReference<Double> ux = new AtomicReference<>(0.0);
    private static final AtomicReference<Double> overall = new AtomicReference<>(0.0);

    private ReportStore() {}

    public static void set(double s, double a, double u) {
        speed.set(s);
        accuracy.set(a);
        ux.set(u);
        overall.set((s + a + u) / 3.0);
        System.out.println("📦 ReportStore updated → speed=" + s + " acc=" + a + " ux=" + u + " overall=" + overall.get());
    }

    public static double getSpeed() { return speed.get(); }
    public static double getAccuracy() { return accuracy.get(); }
    public static double getUx() { return ux.get(); }
    public static double getOverall() { return overall.get(); }
}
